# 2600-survivor
Another bad game jam game whose theme is 'retro'
